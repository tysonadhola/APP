import React from 'react';
function App() {
  return (
    <div>
      <h1>G.A Dripyard Kenya</h1>
      <p>KUPIGA LUKU NI SELFCARE</p>
    </div>
  );
}
export default App;